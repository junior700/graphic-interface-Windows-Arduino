// Automacao.cpp : Defines the entry point for the application.
//

#include "StdAfx.h"
#include "dllCom.h"
// Local Header Files
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include "Automacao.h"
//#include "strsafe.h"
#include <commctrl.h>
#include <windowsx.h>

//#include "SerialCom.h"
//#include <strsafe.h>

void CreatePRINT(HWND hDlg);
void CreateControls(HWND hDlg) ;
#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance

wchar_t ENDERECO[1];
wchar_t TIPO[2];
wchar_t CANAL[1];
const long canal[] = {248,249,250,251,252};//canal 0,1,2,3,4
LONG Pos1 = 0;
LONG Pos2 = 0;
LONG Pos3 = 0;
LONG Pos4 = 0;
LONG Pos5 = 0;

wchar_t VALOR[1];
wchar_t TEMPO[1];
char *transmite="      ";
LRESULT sel=0;
char x[3]="D4";
BOOL I[]={FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE};




/*
extern int open_Serial(HWND hwnd, const char *comport,int bytesize,int baudrate,int stopbits,int parity);
extern int varreSerial(HWND hwnd, int baudrate);
extern int close_Serial(HWND hwnd);
extern int ReadData(HWND hwnd, char *buf, unsigned int nbChar);
extern int PRINT(HWND hwnd,char *str);
*/
static HWND hwndCombo, hwndStatic;






// Foward declarations of functions included in this code module:

//VOID CreateSlider1(HWND hwnd);
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Login(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Ilumina(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	Sensor(HWND, UINT, WPARAM, LPARAM);
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text
const wchar_t *items[] = { L"A", L"B",L"C", L"D", L"E", L"F", L"G", L"H"};
//const wchar_t *SAIDA[] = { L"IDC_IMG", L"IDC_IMG1",L"IDC_IMG2", L"IDC_IMG3", L"IDC_IMG4", L"IDC_IMG5", L"IDC_IMG6", L"IDC_IMG7"};
char ITENS[9] = "ABCDEFGH";


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_Automacao, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_Automacao);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//


ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_Automacao);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_Automacao;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}



//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//



BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

  // hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
     // CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);
hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, 400, 100, NULL, NULL, hInstance, NULL);


   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);

	switch (message)
	{


		case WM_CREATE:
        
			 DialogBox(hInst, (LPCTSTR)IDD_DIALOG1, hWnd, (DLGPROC)Login);
			 break;


		case WM_COMMAND:






			wmId    = LOWORD(wParam);
			wmEvent = HIWORD(wParam);
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);

				break;
				
				case IDM_ILUMINA:
				   DialogBox(hInst, (LPCTSTR)IDD_DIALOG2, hWnd, (DLGPROC)Ilumina);

				break;

				case IDM_SENSOR:
				   DialogBox(hInst, (LPCTSTR)IDD_DIALOG4, hWnd, (DLGPROC)Sensor);

				break;


				case IDM_EXIT:
				   DestroyWindow(hWnd);
				break;


				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;





		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code here...
			RECT rt;
			GetClientRect(hWnd, &rt);
			DrawText(hdc, szHello, strlen(szHello), &rt, DT_CENTER);
			EndPaint(hWnd, &ps);
			break;

		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.







LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
   //CHAR *szPos1;
  wchar_t buf[4];
  char y[]=" ";

	switch (message)
	{
		case WM_INITDIALOG:
		{
		wsprintfW(TEMPO, L"%1x", L"0");
		wsprintfW(ENDERECO, L"%1c", L"A");
		SetDlgItemTextW(hDlg, IDC_STATIC5, L"A");
			for (int i = 0; i < 8; i++ ) 
			SendMessageW(GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM) items[i]);
		CreatePRINT(hDlg);
		return TRUE;
		}
		break;



		case WM_COMMAND:
		{


			if (LOWORD(wParam) == IDC_BUTTON1) {
			varreSerial(hDlg, 2400);
			//MessageBeep(MB_OK);
			}


			if (LOWORD(wParam) == IDC_BUTTON2) {
            close_Serial(hDlg);
			SetWindowText(print, TEXT("Desconectado"));
			//MessageBeep(MB_OK);
			}
			
			
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
			{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
			}


			if (HIWORD(wParam) == CBN_SELCHANGE) {
			sel = SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_GETCURSEL, 0, 0);
			wsprintfW(ENDERECO, L"%1c", items[sel]);
			SetDlgItemTextW(hDlg, IDC_STATIC5, items[sel]);
			}
		}
		break;	

		case WM_HSCROLL:
        {    
				 
            if(LOWORD(lParam)!=TB_THUMBTRACK)
            return FALSE;
			
			
						
			case WM_NOTIFY:
			{					
			  	if(Pos5 == SendMessageW(GetDlgItem(hDlg, IDC_SLIDER5), TBM_GETPOS, 0, 0));			
			  	else
				{
				Pos5 = SendMessage(GetDlgItem(hDlg, IDC_SLIDER5), TBM_GETPOS, 0, 0);
				wsprintfW(buf, L"%ld", Pos5);
				SetDlgItemTextW(hDlg, IDC_STATIC6, buf);
				wsprintfW(TEMPO, L"%lx", Pos5);
				return TRUE	;
				}
									                     

				switch (((LPNMHDR)lParam)->code)
				{
					case NM_RELEASEDCAPTURE:
					{
                             //ReleaseCapture();
								
						switch (((LPNMHDR)lParam)->idFrom)
						{					
						
							case IDC_SLIDER1:
							{
						
								if(Pos1 == SendMessageW(GetDlgItem(hDlg, IDC_SLIDER1), TBM_GETPOS, 0, 0));			
								else
								{
								Pos1=SendMessage(GetDlgItem(hDlg, IDC_SLIDER1), TBM_GETPOS, 0, 0);
								wsprintfW(buf, L"%ld", Pos1);
								SetDlgItemTextW(hDlg, IDC_STATIC1, buf);
								WriteData(hDlg,x,2);//envia D4 (endere�o relativo a dimmer de 4 canais)
								y[0] = ITENS[sel];
								WriteData(hDlg,y,1);//envia endere�o do canal: A,B,C,D,...,H.
								y[0]=248;//
								WriteData(hDlg,y,1);//envia canal do dimmer:1,2,3 ou 4
								y[0]=Pos5;
								WriteData(hDlg,y,1);//envia tempo de dimeriza��o (0 a 100s)
								y[0]= 127*(100-Pos1)/100;
								WriteData(hDlg,y,1);//envia valor de dimeriza��o (127 a 0 correspondente a 0% a 100%)
								return TRUE;
								}
							}
							break;
							
							case IDC_SLIDER2:
							{
								if(Pos2 == SendMessageW(GetDlgItem(hDlg, IDC_SLIDER2), TBM_GETPOS, 0, 0));			
								else
								{
								Pos2=SendMessage(GetDlgItem(hDlg, IDC_SLIDER2), TBM_GETPOS, 0, 0);
								wsprintfW(buf, L"%ld", Pos2);
								SetDlgItemTextW(hDlg, IDC_STATIC2, buf);
								WriteData(hDlg,x,2);//envia D4 (endere�o relativo a dimmer de 4 canais)
								y[0] = ITENS[sel];
								WriteData(hDlg,y,1);//envia endere�o do canal: A,B,C,D,...,H.
								y[0]=249;//
								WriteData(hDlg,y,1);//envia canal do dimmer:1,2,3 ou 4
								y[0]=Pos5;
								WriteData(hDlg,y,1);//envia tempo de dimeriza��o (0 a 100s)
								y[0]= 127*(100-Pos2)/100;
								WriteData(hDlg,y,1);//envia valor de dimeriza��o (127 a 0 correspondente a 0% a 100%)
								return TRUE;
								}
							}
							break;
								
							case IDC_SLIDER3:
							{
								if(Pos3 == SendMessageW(GetDlgItem(hDlg, IDC_SLIDER3), TBM_GETPOS, 0, 0));			
								else
								{
								Pos3=SendMessage(GetDlgItem(hDlg, IDC_SLIDER3), TBM_GETPOS, 0, 0);
								wsprintfW(buf, L"%ld", Pos3);
								SetDlgItemTextW(hDlg, IDC_STATIC3, buf);
								WriteData(hDlg,x,2);//envia D4 (endere�o relativo a dimmer de 4 canais)
								y[0] = ITENS[sel];
								WriteData(hDlg,y,1);//envia endere�o do canal: A,B,C,D,...,H.
								y[0]=250;//
								WriteData(hDlg,y,1);//envia canal do dimmer:1,2,3 ou 4
								y[0]=Pos5;
								WriteData(hDlg,y,1);//envia tempo de dimeriza��o (0 a 100s)
								y[0]= 127*(100-Pos3)/100;
								WriteData(hDlg,y,1);//envia valor de dimeriza��o (127 a 0 correspondente a 0% a 100%)
								return TRUE;
								}
							}
							break;
								
							case IDC_SLIDER4:
							{	

								if(Pos4 == SendMessageW(GetDlgItem(hDlg, IDC_SLIDER4), TBM_GETPOS, 0, 0));			
								else
								{
								Pos4=SendMessage(GetDlgItem(hDlg, IDC_SLIDER4), TBM_GETPOS, 0, 0);
								wsprintfW(buf, L"%ld", Pos4);
								SetDlgItemTextW(hDlg, IDC_STATIC4, buf);
								WriteData(hDlg,x,2);//envia D4 (endere�o relativo a dimmer de 4 canais)
								y[0] = ITENS[sel];
								WriteData(hDlg,y,1);//envia endere�o do canal: A,B,C,D,...,H.
								y[0]=251;//
								WriteData(hDlg,y,1);//envia canal do dimmer:1,2,3 ou 4
								y[0]=Pos5;
								WriteData(hDlg,y,1);//envia tempo de dimeriza��o (0 a 100s)
								y[0]= 127*(100-Pos4)/100;
								WriteData(hDlg,y,1);//envia valor de dimeriza��o (127 a 0 correspondente a 0% a 100%)
								return TRUE;
								}
							}
							break;
						}
					    
            		}
					break;
				}
				
		
			}
			break;
		}
        break;
	}
return FALSE;
}











LRESULT CALLBACK Login(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
   //CHAR *szPos1;


	switch (message)
	{
		case WM_INITDIALOG:

     
        return TRUE;





		case WM_COMMAND:
		



			if (LOWORD(wParam) == IDC_BUTTON1 )// || LOWORD(wParam) == IDCANCEL)
			{
					char *LOGIN="admin";
					char *SENHA="1234";
				    char buffer[256];
					SendMessage(GetDlgItem(hDlg, IDC_EDIT1),
					WM_GETTEXT,
					sizeof(buffer)/sizeof(buffer[0]),
					reinterpret_cast<LPARAM>(buffer));
                    int ret = strncmp(LOGIN, buffer, 9);

					SendMessage(GetDlgItem(hDlg, IDC_EDIT2),
					WM_GETTEXT,
					sizeof(buffer)/sizeof(buffer[0]),
					reinterpret_cast<LPARAM>(buffer));
					
					int ret1 = strncmp(SENHA, buffer, 8); 
 
  
				
				
				if(ret==0 & ret1==0)
				{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
				}
			}
            
			if (LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, LOWORD(wParam));
				PostQuitMessage(0);
				return TRUE;
				}



			break;



		case WM_NOTIFY:


			

			break;

		
	}
    return FALSE;
}




LRESULT CALLBACK Sensor(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
   
   
	switch (message)
	{
			
		case WM_COMMAND:

			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
			{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
			}
		break;

	}
return FALSE;
}




LRESULT CALLBACK Ilumina(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
   //CHAR *szPos1;
	HICON hIcon1;
	
	int i=0;
   
	switch (message)
	{

		case WM_INITDIALOG:
		{
			for(int m=0;m<8;m++)
			{
				if(I[m])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, (1031+m)), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}

        return TRUE;
		}
		break;

		case WM_COMMAND:
		{
			
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}

			if (LOWORD(wParam) == IDC_BUTTON9 )
			{
				i=0;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}
			if (LOWORD(wParam) == IDC_BUTTON2 )
			{
				i=1;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG1), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}
			if (LOWORD(wParam) == IDC_BUTTON3 )
			{
				i=2;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG2), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}
			if (LOWORD(wParam) == IDC_BUTTON4 )
			{
				i=3;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG3), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}
			if (LOWORD(wParam) == IDC_BUTTON5 )
			{
				i=4;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG4), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}
			if (LOWORD(wParam) == IDC_BUTTON6 )
			{
				i=5;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG5), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}
			if (LOWORD(wParam) == IDC_BUTTON7 )
			{
				i=6;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG6), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}
			if (LOWORD(wParam) == IDC_BUTTON8 )
			{
				i=7;
				I[i]=!I[i];
				if(I[i])
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON7);
				else
				hIcon1 = LoadIcon(hInst, (LPCTSTR)IDI_ICON8);

				SendMessage( GetDlgItem(hDlg, IDC_IMG7), STM_SETIMAGE, (WPARAM)IMAGE_ICON, (LPARAM)hIcon1);

			}


	}		
		
break;
	}
    return FALSE;
}




void CreatePRINT(HWND hDlg)
{


 print = CreateWindowW(L"Static", L"Desconectado", WS_CHILD | WS_VISIBLE
        , 10, 270, 400, 30, hDlg, (HMENU) ID_STATIC, NULL,NULL);


	return;
}





void EnviaDados(HWND hDlg,HWND )
{


 print = CreateWindowW(L"Static", L"Desconectado", WS_CHILD | WS_VISIBLE
        , 10, 270, 400, 30, hDlg, (HMENU) ID_STATIC, NULL,NULL);


	return;
}







