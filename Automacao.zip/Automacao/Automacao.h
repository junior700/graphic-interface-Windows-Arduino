
#if !defined(AFX_Automacao_H__2B22AAB1_F440_4B65_A740_8EF1FD06EAAD__INCLUDED_)
#define AFX_Automacao_H__2B22AAB1_F440_4B65_A740_8EF1FD06EAAD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_Automacao_H__2B22AAB1_F440_4B65_A740_8EF1FD06EAAD__INCLUDED_)

