
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the DLLCOM_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// DLLCOM_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef DLLCOM_EXPORTS
#define DLLCOM_API __declspec(dllexport)
#else
#define DLLCOM_API __declspec(dllimport)
#endif
#define ARDUINO_WAIT_TIME 2000

// This class is exported from the dllCOM.dll
class DLLCOM_API CDllCOM {
public:
	CDllCOM(void);
	// TODO: add your methods here.
};




//vari�veis
extern DLLCOM_API int nDllCOM;
extern DLLCOM_API HWND wind;
extern DLLCOM_API HWND print;
extern DLLCOM_API HANDLE hSerial;
extern DLLCOM_API BOOL connected;
extern DLLCOM_API COMSTAT status;
extern DLLCOM_API DWORD errors;
extern DLLCOM_API DCB dcbSerialParams ;
extern DLLCOM_API COMMTIMEOUTS timeouts;
extern DLLCOM_API const wchar_t *MEN[] ;

//fun��es
DLLCOM_API int fnDllCOM(void);
DLLCOM_API int open_Serial(HWND hWnd, const char *comport,int bytesize,int baudrate,int stopbits,int parity);
DLLCOM_API int varreSerial(HWND hWnd, int baudrate);
DLLCOM_API int close_Serial(HWND hWnd);
DLLCOM_API int ReadData(HWND hWnd, char *buf, unsigned int nbChar);
DLLCOM_API int WriteData(HWND hWnd, const char *buf, unsigned int nbChar);
DLLCOM_API int PRINT(HWND hDlg,char *str);

